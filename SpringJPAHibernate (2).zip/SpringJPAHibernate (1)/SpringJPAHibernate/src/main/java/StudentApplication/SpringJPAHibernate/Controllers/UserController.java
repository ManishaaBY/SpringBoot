package StudentApplication.SpringJPAHibernate.Controllers;

import StudentApplication.SpringJPAHibernate.Model.User;
import StudentApplication.SpringJPAHibernate.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserRepository userRepoObj;
    @PostMapping("/signup")

    public User save(@RequestBody User userObj){

        User userResponse = userRepoObj.save(userObj);

        System.out.println(userObj);
        return userResponse;
    }
    @GetMapping("/all")
    public List<User> find(){
        return userRepoObj.findAll();
    }
    @DeleteMapping("/delete")
    public void deleteUser(@RequestBody User userObj) {
        userRepoObj.delete(userObj);
    }




}

